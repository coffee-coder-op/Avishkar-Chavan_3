"""
Secure Random Password Generator
=================================

A desktop GUI application for generating cryptographically secure passwords.

Author : (your name here)
Course : (your course/project name here)

This application uses:
    - tkinter  -> Graphical User Interface
    - secrets  -> Cryptographically secure random generation
    - string   -> Character set definitions
    - pyperclip -> Clipboard integration

IMPORTANT SECURITY NOTE:
    This project intentionally uses the `secrets` module instead of the
    `random` module. The `random` module is NOT safe for generating
    passwords, tokens, or any other security-sensitive values because it
    is a deterministic pseudo-random generator that can be predicted.
    `secrets` uses the operating system's cryptographically secure random
    number source, which is the officially recommended approach by the
    Python documentation: https://docs.python.org/3/library/secrets.html
"""

import string
import secrets
import tkinter as tk
from tkinter import ttk, messagebox

# pyperclip is an external dependency (see requirements.txt)
try:
    import pyperclip
    PYPERCLIP_AVAILABLE = True
except ImportError:
    # The app must not crash even if pyperclip is missing.
    # We simply disable clipboard features and warn the user instead.
    PYPERCLIP_AVAILABLE = False


# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------

MIN_LENGTH = 8
MAX_LENGTH = 64
MAX_HISTORY = 5

# Characters that are commonly confused with one another when displayed
# in certain fonts (zero, capital O, lowercase L, digit one).
AMBIGUOUS_CHARACTERS = "0Ol1"


class PasswordGeneratorApp:
    """Main application class for the Secure Password Generator."""

    def __init__(self, root):
        self.root = root
        self.root.title("Secure Password Generator")
        self.root.geometry("520x680")
        self.root.resizable(False, False)
        self.root.configure(bg="#f4f6f8")

        # In-memory session-only history (never written to disk).
        self.history = []

        # Holds the most recently generated password so the
        # "Copy to Clipboard" button knows what to copy.
        self.current_password = ""

        # Build the UI.
        self._build_styles()
        self._build_widgets()

    # ----------------------------------------------------------------
    # UI CONSTRUCTION
    # ----------------------------------------------------------------

    def _build_styles(self):
        """Configure ttk styles for a clean, modern look."""
        style = ttk.Style()
        # 'clam' theme renders consistently and looks modern on Windows.
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass  # Fall back to default theme if 'clam' is unavailable.

        style.configure("TFrame", background="#f4f6f8")
        style.configure("TLabel", background="#f4f6f8", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("Section.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("TButton", font=("Segoe UI", 10), padding=6)
        style.configure("TCheckbutton", background="#f4f6f8", font=("Segoe UI", 10))

    def _build_widgets(self):
        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.pack(fill="both", expand=True)

        # ---------------- Title ----------------
        title_label = ttk.Label(
            main_frame, text="Secure Password Generator", style="Title.TLabel"
        )
        title_label.pack(pady=(0, 15))

        # ---------------- Password Display ----------------
        display_frame = ttk.Frame(main_frame)
        display_frame.pack(fill="x", pady=(0, 10))

        self.password_var = tk.StringVar(value="")
        self.password_entry = ttk.Entry(
            display_frame,
            textvariable=self.password_var,
            font=("Consolas", 14),
            justify="center",
            state="readonly",
        )
        self.password_entry.pack(fill="x", ipady=6)

        # ---------------- Length Control ----------------
        length_frame = ttk.Frame(main_frame)
        length_frame.pack(fill="x", pady=(15, 5))

        ttk.Label(length_frame, text="Password Length (8 - 64):", style="Section.TLabel").pack(
            anchor="w"
        )

        self.length_var = tk.IntVar(value=12)
        length_control_frame = ttk.Frame(length_frame)
        length_control_frame.pack(fill="x", pady=5)

        self.length_scale = ttk.Scale(
            length_control_frame,
            from_=MIN_LENGTH,
            to=MAX_LENGTH,
            orient="horizontal",
            variable=self.length_var,
            command=self._on_scale_change,
        )
        self.length_scale.pack(side="left", fill="x", expand=True, padx=(0, 10))

        self.length_spinbox = tk.Spinbox(
            length_control_frame,
            from_=MIN_LENGTH,
            to=MAX_LENGTH,
            width=5,
            textvariable=self.length_var,
            font=("Segoe UI", 10),
            justify="center",
        )
        self.length_spinbox.pack(side="left")

        # ---------------- Character Type Checkboxes ----------------
        options_frame = ttk.Frame(main_frame)
        options_frame.pack(fill="x", pady=(15, 5))

        ttk.Label(options_frame, text="Character Types:", style="Section.TLabel").pack(anchor="w")

        self.use_uppercase = tk.BooleanVar(value=True)
        self.use_lowercase = tk.BooleanVar(value=True)
        self.use_numbers = tk.BooleanVar(value=True)
        self.use_symbols = tk.BooleanVar(value=True)
        self.exclude_ambiguous = tk.BooleanVar(value=False)

        checks_frame = ttk.Frame(options_frame)
        checks_frame.pack(fill="x", pady=5)

        ttk.Checkbutton(
            checks_frame, text="Uppercase (A-Z)", variable=self.use_uppercase
        ).grid(row=0, column=0, sticky="w", padx=5, pady=3)
        ttk.Checkbutton(
            checks_frame, text="Lowercase (a-z)", variable=self.use_lowercase
        ).grid(row=0, column=1, sticky="w", padx=5, pady=3)
        ttk.Checkbutton(
            checks_frame, text="Numbers (0-9)", variable=self.use_numbers
        ).grid(row=1, column=0, sticky="w", padx=5, pady=3)
        ttk.Checkbutton(
            checks_frame, text="Symbols (!@#$...)", variable=self.use_symbols
        ).grid(row=1, column=1, sticky="w", padx=5, pady=3)

        ttk.Checkbutton(
            options_frame,
            text="Exclude ambiguous characters (0, O, l, 1)",
            variable=self.exclude_ambiguous,
        ).pack(anchor="w", pady=(5, 0))

        # ---------------- Buttons ----------------
        buttons_frame = ttk.Frame(main_frame)
        buttons_frame.pack(fill="x", pady=15)

        generate_btn = ttk.Button(
            buttons_frame, text="Generate Password", command=self.generate_password
        )
        generate_btn.pack(side="left", expand=True, fill="x", padx=(0, 5))

        copy_btn = ttk.Button(
            buttons_frame, text="Copy to Clipboard", command=self.copy_to_clipboard
        )
        copy_btn.pack(side="left", expand=True, fill="x", padx=(5, 0))

        # ---------------- Status / Confirmation Label ----------------
        self.status_var = tk.StringVar(value="")
        self.status_label = ttk.Label(
            main_frame, textvariable=self.status_var, foreground="#2e7d32"
        )
        self.status_label.pack(fill="x", pady=(0, 5))

        # ---------------- Strength Indicator ----------------
        strength_frame = ttk.Frame(main_frame)
        strength_frame.pack(fill="x", pady=(5, 10))

        ttk.Label(strength_frame, text="Password Strength:", style="Section.TLabel").pack(
            anchor="w"
        )

        strength_row = ttk.Frame(strength_frame)
        strength_row.pack(fill="x", pady=5)

        self.strength_bar = ttk.Progressbar(
            strength_row, orient="horizontal", length=300, mode="determinate", maximum=100
        )
        self.strength_bar.pack(side="left", padx=(0, 10))

        self.strength_var = tk.StringVar(value="N/A")
        self.strength_label = ttk.Label(
            strength_row, textvariable=self.strength_var, font=("Segoe UI", 10, "bold")
        )
        self.strength_label.pack(side="left")

        # ---------------- History ----------------
        history_frame = ttk.Frame(main_frame)
        history_frame.pack(fill="both", expand=True, pady=(10, 0))

        history_header = ttk.Frame(history_frame)
        history_header.pack(fill="x")

        ttk.Label(history_header, text="Generation History (last 5):", style="Section.TLabel").pack(
            side="left"
        )

        clear_history_btn = ttk.Button(
            history_header, text="Clear History", command=self.clear_history
        )
        clear_history_btn.pack(side="right")

        self.history_listbox = tk.Listbox(
            history_frame, height=6, font=("Consolas", 10), activestyle="none"
        )
        self.history_listbox.pack(fill="both", expand=True, pady=(5, 0))

    # ----------------------------------------------------------------
    # EVENT HANDLERS / CALLBACKS
    # ----------------------------------------------------------------

    def _on_scale_change(self, value):
        """Keep the Scale and Spinbox synced with integer values only."""
        try:
            self.length_var.set(int(float(value)))
        except (TypeError, ValueError):
            pass

    def generate_password(self):
        """Validate inputs and generate a new secure password."""
        self.status_var.set("")

        # ---- Validate password length ----
        try:
            length = int(self.length_var.get())
        except (tk.TclError, ValueError):
            messagebox.showerror("Invalid Length", "Password length must be a whole number.")
            return

        if length < MIN_LENGTH or length > MAX_LENGTH:
            messagebox.showerror(
                "Invalid Length",
                f"Password length must be between {MIN_LENGTH} and {MAX_LENGTH} characters.",
            )
            return

        # ---- Build the list of selected character categories ----
        selected_categories = self._get_selected_categories()

        if len(selected_categories) < 2:
            messagebox.showerror(
                "Not Enough Character Types",
                "Please select at least 2 character types "
                "(Uppercase, Lowercase, Numbers, Symbols).",
            )
            return

        # ---- Generate the password securely ----
        try:
            password = self._generate_secure_password(length, selected_categories)
        except ValueError as error:
            # This covers the edge case where filtering ambiguous characters
            # leaves a category with zero usable characters.
            messagebox.showerror("Generation Error", str(error))
            return

        # ---- Update UI with the new password ----
        self.current_password = password
        self.password_var.set(password)

        self._update_strength_indicator(password, len(selected_categories))
        self._add_to_history(password)

        # ---- Automatically copy to clipboard ----
        self._copy_text(password, auto=True)

    def _get_selected_categories(self):
        """Return a dict of {category_name: character_set} for selected types."""
        categories = {}

        if self.use_uppercase.get():
            chars = string.ascii_uppercase
            if self.exclude_ambiguous.get():
                chars = self._strip_ambiguous(chars)
            categories["uppercase"] = chars

        if self.use_lowercase.get():
            chars = string.ascii_lowercase
            if self.exclude_ambiguous.get():
                chars = self._strip_ambiguous(chars)
            categories["lowercase"] = chars

        if self.use_numbers.get():
            chars = string.digits
            if self.exclude_ambiguous.get():
                chars = self._strip_ambiguous(chars)
            categories["numbers"] = chars

        if self.use_symbols.get():
            # Symbols are never affected by the ambiguous-character filter,
            # since none of 0/O/l/1 are symbols. Included here for clarity.
            categories["symbols"] = string.punctuation

        return categories

    @staticmethod
    def _strip_ambiguous(char_set):
        """Remove ambiguous characters (0, O, l, 1) from a character set."""
        return "".join(c for c in char_set if c not in AMBIGUOUS_CHARACTERS)

    def _generate_secure_password(self, length, categories):
        """
        Generate a cryptographically secure password that:
          1. Contains at least one character from every selected category.
          2. Fills remaining length securely from the combined character pool.
          3. Is securely shuffled using the `secrets` module.

        Raises:
            ValueError: if any selected category has no usable characters
                        left after ambiguous-character filtering.
        """
        # Safety check: make sure no category became empty after filtering.
        for name, chars in categories.items():
            if len(chars) == 0:
                raise ValueError(
                    f"The '{name}' category has no characters left after "
                    "excluding ambiguous characters. Please deselect "
                    "'Exclude ambiguous characters' or choose another type."
                )

        # Step 1: Guarantee at least one character from each selected category.
        password_chars = [secrets.choice(chars) for chars in categories.values()]

        # Step 2: Build the combined pool for filling the remaining length.
        combined_pool = "".join(categories.values())

        remaining_length = length - len(password_chars)
        password_chars.extend(secrets.choice(combined_pool) for _ in range(remaining_length))

        # Step 3: Securely shuffle the password so the guaranteed characters
        # are not always in the first few positions. secrets.SystemRandom
        # provides a shuffle() method backed by the OS's secure RNG.
        secure_random = secrets.SystemRandom()
        secure_random.shuffle(password_chars)

        return "".join(password_chars)

    def _update_strength_indicator(self, password, category_count):
        """Calculate and display password strength based on length & diversity."""
        length = len(password)

        # Simple, explainable scoring rules for a college-level project.
        if length >= 16 and category_count >= 3:
            strength = "STRONG"
            score = 100
            color = "#2e7d32"  # green
        elif length >= 12 and category_count >= 2:
            strength = "MEDIUM"
            score = 65
            color = "#f9a825"  # amber
        else:
            strength = "WEAK"
            score = 30
            color = "#c62828"  # red

        self.strength_var.set(strength)
        self.strength_bar["value"] = score
        self.strength_label.configure(foreground=color)

    def _add_to_history(self, password):
        """Add a password to the in-memory history, keeping only the last 5."""
        self.history.append(password)
        if len(self.history) > MAX_HISTORY:
            self.history.pop(0)  # Remove the oldest entry.

        self._refresh_history_display()

    def _refresh_history_display(self):
        self.history_listbox.delete(0, tk.END)
        for index, pwd in enumerate(self.history, start=1):
            self.history_listbox.insert(tk.END, f"{index}. {pwd}")

    def clear_history(self):
        """Clear the in-memory password history (nothing is stored on disk)."""
        self.history.clear()
        self._refresh_history_display()
        self.status_var.set("History cleared.")

    def copy_to_clipboard(self):
        """Manually copy the currently displayed password to the clipboard."""
        if not self.current_password:
            messagebox.showwarning(
                "No Password", "Please generate a password before copying."
            )
            return

        self._copy_text(self.current_password, auto=False)

    def _copy_text(self, text, auto):
        """Shared clipboard-copy logic with graceful error handling."""
        if not PYPERCLIP_AVAILABLE:
            self.status_var.set("Clipboard unavailable: pyperclip is not installed.")
            self.status_label.configure(foreground="#c62828")
            return

        try:
            pyperclip.copy(text)
            self.status_var.set("Password copied to clipboard!")
            self.status_label.configure(foreground="#2e7d32")
        except Exception:
            # Clipboard access can fail on some systems/environments
            # (e.g., no clipboard utility available). The app must not crash.
            prefix = "Auto-copy failed" if auto else "Copy failed"
            self.status_var.set(f"{prefix}: clipboard is unavailable on this system.")
            self.status_label.configure(foreground="#c62828")


def main():
    """Entry point for the application."""
    root = tk.Tk()
    app = PasswordGeneratorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
